#ifndef __STRING_H
#define __STRING_H

extern int strlen (__const char *__s);

#endif /* __STRING_H */
