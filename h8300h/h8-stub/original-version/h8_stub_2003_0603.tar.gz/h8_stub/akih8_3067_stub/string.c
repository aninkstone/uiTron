#include <stddef.h>
#pragma align 2

/* Implementation taken from Linux kernel (linux/lib/string.c) */

size_t strlen(const char * s)
{
    const char *sc;

    for (sc = s; *sc != '\0'; ++sc)
        /* nothing */;
    return sc - s;
}

void * memcpy(void * dest,const void *src,size_t count)
{
    char *tmp = (char *) dest, *s = (char *) src;

    while (count--)
        *tmp++ = *s++;

    return dest;
}
